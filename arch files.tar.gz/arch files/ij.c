#include<stdio.h>
int arr1[500][500];
void main()
{
int i=0,j=0;
while(i<500)
{
	while(j<500)
		{
			arr1[i][j]=j+i;
			j+=1;
		}
	j=0;
	i+=1;
}

i=0;j=0;

while(i<500)
{
        while(j<500)
                {
                        arr1[i][j];
                        j+=1;   
                }
	j=0;
        i+=1;   
}}
