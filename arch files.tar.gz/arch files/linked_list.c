#include<stdio.h>

struct merge {
	long long int val;
	long long int key;
	};
	struct merge MA[1000000];

void main() {
long long int i=0;
for(i=0;i<1000000;i++) {
MA[i].key=3+i;
MA[i].val=34+i;
}
for(i=0;i<1000000;i++) {
MA[i].key;
MA[i].val;
}

}
